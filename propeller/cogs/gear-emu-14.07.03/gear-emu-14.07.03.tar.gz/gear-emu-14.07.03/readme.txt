Gear: Parallax Inc. Propeller emulator

Copyright 2007 - Robert Vandiver
Copyright 2009 - mirror
Copyright 2014 - Antonio Sanhueza

Released under the Lesser GNU Public Licence (LGPL)
See Licence.txt for details

Developers:

Robert Bryon Vandiver (asterick@buxx.com)
mirror
Antonio Sanhueza (gatuno)
Ben Levitt (benjie)

Contributed code by:

Windows Forms Collapsible Splitter Control for .Net
(c)Copyright 2002-2003 NJF (furty74@yahoo.com). All rights reserved.
