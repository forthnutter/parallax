using System;
using System.Collections.Generic;
using System.Text;

namespace Gear.EmulationCore
{
    public static class DisassemblerStrings
    {
        static public string[] InterpretedOps;
        static public Dictionary<byte, string> EffectCodes;
    }
}
